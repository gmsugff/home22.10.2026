package com.example.pictureviewer

import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.bumptech.glide.Glide
import java.io.File
import java.net.URL


class MainActivity : AppCompatActivity() {

    private lateinit var imageView: ImageView
    private lateinit var editTextUrl: EditText
    private lateinit var textViewStatus: TextView
    private var currentPhotoPath: String? = null

    private val pictures = listOf(R.drawable.sample_picture, R.drawable.sample_picture_2)
    private var pictureIndex = 0

    private val scaleTypes = listOf(
        ImageView.ScaleType.FIT_CENTER,
        ImageView.ScaleType.CENTER_CROP,
        ImageView.ScaleType.CENTER_INSIDE,
        ImageView.ScaleType.FIT_XY
    )
    private var scaleIndex = 0

    private val cameraLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            textViewStatus.setText(R.string.status_photo_taken)
            currentPhotoPath?.let {
                Glide.with(this).load(File(it)).into(imageView)
            }
        } else {
            textViewStatus.setText(R.string.status_photo_cancelled)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imageView = findViewById(R.id.imageView)
        editTextUrl = findViewById(R.id.urlEditText)
        textViewStatus = findViewById(R.id.textViewStatus)

        findViewById<Button>(R.id.btnLoadManual).setOnClickListener { loadImageManually() }
        findViewById<Button>(R.id.btnLoadGlide).setOnClickListener { loadImageWithGlide() }
        findViewById<Button>(R.id.buttonNextPicture).setOnClickListener { showNextPicture() }
        findViewById<Button>(R.id.buttonScaleType).setOnClickListener { nextScaleType() }
        findViewById<Button>(R.id.buttonReset).setOnClickListener { resetAll() }

        findViewById<Button>(R.id.buttonTakePhoto).setOnClickListener { takePhoto(false) }
        findViewById<Button>(R.id.buttonTakeSelfie).setOnClickListener { takePhoto(true) }

        if (savedInstanceState != null) {
            currentPhotoPath = savedInstanceState.getString("KEY_PHOTO_PATH")
            currentPhotoPath?.let {
                Glide.with(this).load(File(it)).into(imageView)
            }
        }
    }

    private fun takePhoto(front: Boolean) {
        val photosDir = File(cacheDir, "photos")
        if (photosDir.exists()) {
            photosDir.listFiles()?.forEach { it.delete() }
        } else {
            photosDir.mkdirs()
        }

        val photoFile = File(photosDir, "photo_${System.currentTimeMillis()}.jpg")
        currentPhotoPath = photoFile.absolutePath

        val photoUri: Uri = FileProvider.getUriForFile(
            this,
           "com.example.pictureviewer.fileprovider",
            photoFile
        )

        val intent = android.content.Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)
        intent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, photoUri)
        if (front) {
            intent.putExtra("android.intent.extras.CAMERA_FACING", 1)
        }

        try {
            cameraLauncher.launch(intent)
        } catch (e: Exception) {
            Toast.makeText(this, R.string.error_camera, Toast.LENGTH_SHORT).show()
        }
    }

    private fun showNextPicture() {
        pictureIndex = (pictureIndex + 1) % pictures.size
        imageView.setImageResource(pictures[pictureIndex])
        textViewStatus.setText(R.string.status_ready)
    }

    private fun nextScaleType() {
        scaleIndex = (scaleIndex + 1) % scaleTypes.size
        imageView.scaleType = scaleTypes[scaleIndex]
        textViewStatus.text = scaleTypes[scaleIndex].name
    }

    private fun resetAll() {
        pictureIndex = 0
        imageView.setImageResource(pictures[pictureIndex])
        editTextUrl.setText(R.string.default_url)
        textViewStatus.setText(R.string.status_ready)
    }

    private fun readAddress(): String? {
        val address = editTextUrl.text.toString().trim()
        if (address.isEmpty()) {
            Toast.makeText(this, R.string.error_empty_url, Toast.LENGTH_SHORT).show()
            return null
        }
        return address
    }

    private fun loadImageManually() {
        val address = readAddress() ?: return
        Thread {
            try {
                val connection = URL(address).openConnection()
                connection.connect()
                val input = connection.getInputStream()
                val bitmap = BitmapFactory.decodeStream(input)
                input.close()
                runOnUiThread { imageView.setImageBitmap(bitmap) }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Ошибка: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    private fun loadImageWithGlide() {
        val address = readAddress() ?: return
        Glide.with(this)
            .load(address)
            .circleCrop()
            .into(imageView)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("KEY_PHOTO_PATH", currentPhotoPath)
    }
}